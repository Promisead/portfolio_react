import React from "react";
import "./Testimonials.css";
import avt1 from "../../assets/avatar1.jpg";
import avt2 from "../../assets/avatar2.jpg";
import avt3 from "../../assets/avatar3.jpg";
import avt4 from "../../assets/avatar4.jpg";

// Import Swiper React components
import { Swiper, SwiperSlide } from "swiper/react";

// Import Swiper styles
import "swiper/css";
import "swiper/css/pagination";

// import required modules
import { Pagination } from "swiper";

const data = [
  {
    avatar: avt1,
    name: "John Doe",
    review:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Minima, tenetur!",
  },
  {
    avatar: avt2,
    name: "Mercy LAne",
    review:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Minima, tenetur!",
  },
  {
    avatar: avt3,
    name: "Sean Diapper",
    review:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Minima, tenetur!",
  },
  {
    avatar: avt4,
    name: "Donaldo Vince",
    review:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Minima, tenetur!",
  },
];

export const Testimonials = () => {
  return (
    <section id="testimonials">
      <h5>Reviews from clients</h5>
      <h2>Testimonials</h2>

      <Swiper
        className="container testimonials__container"
        pagination={{ clickable: true }}
        modules={[Pagination]}
        spaceBetween={40}
        slidesPerView={1}
      >
        {data.map(({ avatar, name, review }, index) => {
          return (
            <SwiperSlide key={index} className="testimonials">
              <div className="client__avatar">
                <img src={avatar} alt={name} />
              </div>
              <h5 className="client__review"> {name} </h5>
              <small>{review}</small>
            </SwiperSlide>
          );
        })}
      </Swiper>
    </section>
  );
};
